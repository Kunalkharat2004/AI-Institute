import React from "react";
import LoginForm from "./components/LoginForm";
import sampleImage from "./assets/table.png"; 
import backgroundImage from "./assets/bg.png"; 
import "./App.css"

const App = () => {
  return (
    <div
      className="min-h-screen bg-gradient-to-bl from-blue-900 to-black text-white"
      style={{
        backgroundImage: `url(${backgroundImage})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
      }}
    >
      <div className="container mx-auto p-2">
        <div className="grid grid-cols-1 md:grid-cols-9 gap-4 mt-20 -ml-10">
          <div className="md:col-span-7 bg-transparent rounded-lg flex flex-col items-start shadow-cyan-200 mt-3 p-2"
          style={{
            boxShadow: `
              0 0 15px rgba(142, 216, 229, 0.5),   /* Close inner glow */
              0 0 30px rgba(142, 216, 229, 0.3),   /* Slightly further glow */
              0 0 45px rgba(142, 216, 229, 0.2),   /* Even further glow */
              0 0 60px rgba(142, 216, 229, 0.1)    /* Outermost glow */
            `,
          }}
          >
            <img
              src={sampleImage}
              alt="Sample"
              className="object-fill h-full w-full"
            />
            <a
              href="https://www.aicte-india.org/sites/default/files/approval/2025-26/Groupwise-List%20of%20Institutions_compressed.pdf"
              target="_blank"
              rel="noopener noreferrer"
              className="mt-0 text-left font-light animate-color-change"
            >
              Groupwise Bifurcation of Institutions for Approval Process 2025-26
            </a>
          </div>
          <div className="md:col-span-2 bg-transparent rounded-lg mt-3">
            <LoginForm />
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
