import React from "react";
import logo from "../assets/logo.png";

const LoginForm = () => {
  return (
    <div
      className="flex flex-col items-center bg-sky-600 p-8 rounded-lg shadow-lg w-80 bg-opacity-5"
      style={{
        boxShadow: `
          0 0 15px rgba(142, 216, 229, 0.5),   /* Close inner glow */
          0 0 30px rgba(142, 216, 229, 0.3),   /* Slightly further glow */
          0 0 45px rgba(142, 216, 229, 0.2),   /* Even further glow */
          0 0 60px rgba(142, 216, 229, 0.1)    /* Outermost glow */
        `
      }}
    >
      {/* Logo */}
      <img src={logo} alt="AICTE Logo" className="h-16 w-72 mb-4" />

      {/* Title */}
      <h2 className="text-xl font-bold text-sky-300 mt-6 mb-4">Sign In</h2>

      {/* Form */}
      <form className="w-full">
        <div className="mb-2">
          <input
            type="text"
            placeholder="User Name"
            className="w-full p-1 bg-sky-900 text-white text-xl rounded-3xl border border-sky-900 "
          />
        </div>
        <div className="mb-4">
          <input
            type="password"
            placeholder="Password"
            className="w-full p-1 bg-sky-900 text-white text-xl rounded-3xl border border-sky-900 "
          />
        </div>
        <button
          type="submit"
          className="w-full bg-cyan-300 text-sky-950 font-semibold rounded-md hover:bg-orange-500 focus:outline-none"
        >
          Sign In
        </button>
      </form>

      {/* Footer */}
      <div className="text-center text-white text-sm mt-4">
        <p>
          Don't have account? <br />

          <a href="#" className="text-sky-300 hover:underline font-medium text-sm">
            New Institute <br />
          </a>
        </p>
        <p>
          <a href="#" className="text-sky-300 hover:underline font-medium text-sm">
            Forgot Password? 
          </a>
        </p>
      </div>
    </div>
  );
};

export default LoginForm;
